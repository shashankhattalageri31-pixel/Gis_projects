import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";

export type Station = {
  id: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
  charger_type: string[];
  available_points: number;
  total_points: number;
  price_per_kwh: number;
  rating: number;
  amenities: string[];
  is_active: boolean;
};

export const useStations = () => {
  const queryClient = useQueryClient();

  // Subscribe to realtime changes
  useEffect(() => {
    const channel = supabase
      .channel("stations-realtime")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "charging_stations" },
        () => {
          queryClient.invalidateQueries({ queryKey: ["stations"] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [queryClient]);

  return useQuery({
    queryKey: ["stations"],
    queryFn: async (): Promise<Station[]> => {
      const { data, error } = await supabase
        .from("charging_stations")
        .select("*")
        .eq("is_active", true)
        .order("name");
      if (error) throw error;
      return data;
    },
  });
};
