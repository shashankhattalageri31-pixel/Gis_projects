import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Calendar, Clock, MapPin, Car, Trash2, Loader2, QrCode } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { QRCodeSVG } from "qrcode.react";

interface Booking {
  id: string;
  booking_date: string;
  booking_time: string;
  vehicle_type: string;
  status: string;
  created_at: string;
  station: { name: string; address: string } | null;
}

const MyBookingsPage = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [cancelling, setCancelling] = useState<string | null>(null);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (user) fetchBookings();
  }, [user]);

  const fetchBookings = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("bookings")
      .select("id, booking_date, booking_time, vehicle_type, status, created_at, station:charging_stations(name, address)")
      .eq("user_id", user!.id)
      .order("booking_date", { ascending: false });

    if (error) {
      toast({ title: "Error", description: "Failed to load bookings.", variant: "destructive" });
    } else {
      setBookings((data as unknown as Booking[]) ?? []);
    }
    setLoading(false);
  };

  const cancelBooking = async (id: string) => {
    setCancelling(id);
    const { error } = await supabase.from("bookings").delete().eq("id", id);
    if (error) {
      toast({ title: "Error", description: "Failed to cancel booking.", variant: "destructive" });
    } else {
      setBookings((prev) => prev.filter((b) => b.id !== id));
      toast({ title: "Cancelled", description: "Booking has been cancelled." });
    }
    setCancelling(null);
  };

  const statusColor = (s: string) => {
    if (s === "confirmed") return "default";
    if (s === "completed") return "secondary";
    return "outline";
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-16">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20 pb-12 px-4">
      <div className="container mx-auto max-w-3xl">
        <h1 className="text-3xl font-display font-bold mb-6">My Bookings</h1>

        {bookings.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              <p className="text-lg mb-4">You have no bookings yet.</p>
              <Button onClick={() => navigate("/booking")}>Book a Slot</Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {bookings.map((b) => (
              <Card key={b.id} className="relative overflow-hidden">
                <CardHeader className="pb-3 flex flex-row items-start justify-between">
                  <div>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-primary" />
                      {b.station?.name ?? "Unknown Station"}
                    </CardTitle>
                    {b.station?.address && (
                      <p className="text-sm text-muted-foreground mt-1">{b.station.address}</p>
                    )}
                  </div>
                  <Badge variant={statusColor(b.status)}>{b.status}</Badge>
                </CardHeader>
                <CardContent className="flex flex-wrap items-center gap-4 text-sm">
                  <span className="flex items-center gap-1 text-muted-foreground">
                    <Calendar className="w-4 h-4" />
                    {format(new Date(b.booking_date), "PPP")}
                  </span>
                  <span className="flex items-center gap-1 text-muted-foreground">
                    <Clock className="w-4 h-4" />
                    {b.booking_time}
                  </span>
                  <span className="flex items-center gap-1 text-muted-foreground">
                    <Car className="w-4 h-4" />
                    {b.vehicle_type}
                  </span>
                  <div className="flex gap-2 ml-auto">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          <QrCode className="w-4 h-4 mr-1" />
                          QR
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-xs">
                        <DialogHeader>
                          <DialogTitle className="text-center">Booking QR Code</DialogTitle>
                        </DialogHeader>
                        <div className="flex flex-col items-center gap-3 py-4">
                          <QRCodeSVG
                            value={b.id}
                            size={200}
                            level="M"
                          />
                          <p className="text-sm text-muted-foreground text-center">
                            Show this QR code at the charging station
                          </p>
                        </div>
                      </DialogContent>
                    </Dialog>
                    <Button
                      variant="destructive"
                      size="sm"
                      disabled={cancelling === b.id}
                      onClick={() => cancelBooking(b.id)}
                    >
                      {cancelling === b.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Trash2 className="w-4 h-4 mr-1" />
                      )}
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default MyBookingsPage;
