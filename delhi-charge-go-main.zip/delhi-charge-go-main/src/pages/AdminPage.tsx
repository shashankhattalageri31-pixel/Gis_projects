import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  LayoutDashboard,
  MapPin,
  CalendarCheck,
  MessageSquare,
  Pencil,
  Trash2,
  Plus,
  Loader2,
  Eye,
  BarChart3,
  ImagePlus,
  Cloud,
  Users,
  Database,
  HardDrive,
  Shield,
} from "lucide-react";
import StationPhotoUpload from "@/components/StationPhotoUpload";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";

interface StationForm {
  name: string;
  address: string;
  lat: string;
  lng: string;
  total_points: string;
  available_points: string;
  price_per_kwh: string;
  is_active: boolean;
}

const defaultStationForm: StationForm = {
  name: "",
  address: "",
  lat: "",
  lng: "",
  total_points: "",
  available_points: "",
  price_per_kwh: "",
  is_active: true,
};

const OWNER_EMAIL = "shashankh056@gmail.com";

const AdminPage = () => {
  const { user, loading } = useAuth();
  const isOwner = user?.email === OWNER_EMAIL;
  const queryClient = useQueryClient();
  const [editingStation, setEditingStation] = useState<string | null>(null);
  const [stationForm, setStationForm] = useState<StationForm>(defaultStationForm);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [photoDialogStation, setPhotoDialogStation] = useState<string | null>(null);

  // Fetch profiles (users)
  const { data: profiles = [], isLoading: profilesLoading } = useQuery({
    queryKey: ["admin-profiles"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: isOwner,
  });

  // Fetch table row counts for database overview
  const { data: tableCounts = {} } = useQuery({
    queryKey: ["admin-table-counts"],
    queryFn: async () => {
      const tables = ["charging_stations", "bookings", "contact_messages", "profiles", "station_reviews", "station_photos", "favorite_stations", "user_roles"] as const;
      const counts: Record<string, number> = {};
      for (const table of tables) {
        const { count } = await supabase.from(table).select("*", { count: "exact", head: true });
        counts[table] = count ?? 0;
      }
      return counts;
    },
    enabled: isOwner,
  });

  // Fetch stations
  const { data: stations = [], isLoading: stationsLoading } = useQuery({
    queryKey: ["admin-stations"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("charging_stations")
        .select("*")
        .order("name");
      if (error) throw error;
      return data;
    },
    enabled: isOwner,
  });

  // Fetch all bookings (admin policy allows this)
  const { data: bookings = [], isLoading: bookingsLoading } = useQuery({
    queryKey: ["admin-bookings"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bookings")
        .select("*, charging_stations(name)")
        .order("booking_date", { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: isOwner,
  });

  // Fetch contact messages
  const { data: messages = [], isLoading: messagesLoading } = useQuery({
    queryKey: ["admin-messages"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("contact_messages" as any)
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as any[];
    },
    enabled: isOwner,
  });

  // Mark message as read
  const markRead = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("contact_messages" as any)
        .update({ is_read: true } as any)
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["admin-messages"] }),
  });

  // Delete message
  const deleteMessage = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("contact_messages" as any)
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-messages"] });
      toast.success("Message deleted");
    },
  });

  // Upsert station
  const upsertStation = useMutation({
    mutationFn: async (form: StationForm & { id?: string }) => {
      const payload = {
        name: form.name,
        address: form.address,
        lat: parseFloat(form.lat),
        lng: parseFloat(form.lng),
        total_points: parseInt(form.total_points),
        available_points: parseInt(form.available_points),
        price_per_kwh: parseFloat(form.price_per_kwh),
        is_active: form.is_active,
      };

      if (form.id) {
        const { error } = await supabase
          .from("charging_stations")
          .update(payload)
          .eq("id", form.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("charging_stations")
          .insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-stations"] });
      toast.success(editingStation ? "Station updated!" : "Station added!");
      setDialogOpen(false);
      resetForm();
    },
    onError: (err: Error) => toast.error(err.message),
  });

  // Delete station
  const deleteStation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("charging_stations")
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-stations"] });
      toast.success("Station deleted!");
    },
    onError: (err: Error) => toast.error(err.message),
  });

  // Toggle availability
  const toggleActive = useMutation({
    mutationFn: async ({ id, is_active }: { id: string; is_active: boolean }) => {
      const { error } = await supabase
        .from("charging_stations")
        .update({ is_active })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-stations"] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  // Update available points inline
  const updateAvailability = useMutation({
    mutationFn: async ({ id, available_points }: { id: string; available_points: number }) => {
      const { error } = await supabase
        .from("charging_stations")
        .update({ available_points })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-stations"] });
      toast.success("Availability updated!");
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const resetForm = () => {
    setStationForm(defaultStationForm);
    setEditingStation(null);
  };

  const openEdit = (station: any) => {
    setEditingStation(station.id);
    setStationForm({
      name: station.name,
      address: station.address,
      lat: String(station.lat),
      lng: String(station.lng),
      total_points: String(station.total_points),
      available_points: String(station.available_points),
      price_per_kwh: String(station.price_per_kwh),
      is_active: station.is_active,
    });
    setDialogOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!stationForm.name || !stationForm.address || !stationForm.lat || !stationForm.lng) {
      toast.error("Please fill in all required fields");
      return;
    }
    upsertStation.mutate(
      editingStation ? { ...stationForm, id: editingStation } : stationForm
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user || !isOwner) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="pt-24 pb-16 min-h-screen">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-lg ev-gradient-bg flex items-center justify-center">
              <LayoutDashboard className="w-5 h-5 text-primary-foreground" />
            </div>
            <h1 className="text-3xl font-display font-bold">
              Admin <span className="ev-gradient-text">Dashboard</span>
            </h1>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-8">
            <div className="bg-card border border-border rounded-2xl p-5">
              <p className="text-sm text-muted-foreground">Total Stations</p>
              <p className="text-2xl font-display font-bold">{stations.length}</p>
            </div>
            <div className="bg-card border border-border rounded-2xl p-5">
              <p className="text-sm text-muted-foreground">Active Stations</p>
              <p className="text-2xl font-display font-bold">
                {stations.filter((s: any) => s.is_active).length}
              </p>
            </div>
            <div className="bg-card border border-border rounded-2xl p-5">
              <p className="text-sm text-muted-foreground">Total Bookings</p>
              <p className="text-2xl font-display font-bold">{bookings.length}</p>
            </div>
            <div className="bg-card border border-border rounded-2xl p-5">
              <p className="text-sm text-muted-foreground">Unread Messages</p>
              <p className="text-2xl font-display font-bold">
                {messages.filter((m: any) => !m.is_read).length}
              </p>
            </div>
          </div>

          <Tabs defaultValue="analytics">
            <TabsList className="mb-6 flex-wrap">
              <TabsTrigger value="analytics" className="gap-1.5">
                <BarChart3 className="w-4 h-4" /> Analytics
              </TabsTrigger>
              <TabsTrigger value="stations" className="gap-1.5">
                <MapPin className="w-4 h-4" /> Stations
              </TabsTrigger>
              <TabsTrigger value="photos" className="gap-1.5">
                <ImagePlus className="w-4 h-4" /> Photos
              </TabsTrigger>
              <TabsTrigger value="bookings" className="gap-1.5">
                <CalendarCheck className="w-4 h-4" /> Bookings
              </TabsTrigger>
              <TabsTrigger value="messages" className="gap-1.5">
                <MessageSquare className="w-4 h-4" /> Messages
                {messages.filter((m: any) => !m.is_read).length > 0 && (
                  <Badge variant="destructive" className="ml-1 h-5 px-1.5 text-xs">
                    {messages.filter((m: any) => !m.is_read).length}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="cloud" className="gap-1.5">
                <Cloud className="w-4 h-4" /> Cloud
              </TabsTrigger>
            </TabsList>

            {/* ANALYTICS TAB */}
            <TabsContent value="analytics">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Bookings by Date */}
                <div className="bg-card border border-border rounded-2xl p-5">
                  <h3 className="font-display font-semibold mb-4">Bookings Over Time</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={(() => {
                      const counts: Record<string, number> = {};
                      bookings.forEach((b: any) => {
                        const d = b.booking_date;
                        counts[d] = (counts[d] || 0) + 1;
                      });
                      return Object.entries(counts)
                        .sort(([a], [b]) => a.localeCompare(b))
                        .slice(-14)
                        .map(([date, count]) => ({ date: date.slice(5), count }));
                    })()}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                      <XAxis dataKey="date" className="text-xs" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                      <YAxis allowDecimals={false} tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                      <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }} />
                      <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                {/* Popular Stations */}
                <div className="bg-card border border-border rounded-2xl p-5">
                  <h3 className="font-display font-semibold mb-4">Popular Stations</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie
                        data={(() => {
                          const counts: Record<string, { name: string; count: number }> = {};
                          bookings.forEach((b: any) => {
                            const name = b.charging_stations?.name || "Unknown";
                            if (!counts[name]) counts[name] = { name, count: 0 };
                            counts[name].count++;
                          });
                          return Object.values(counts).sort((a, b) => b.count - a.count).slice(0, 6);
                        })()}
                        dataKey="count"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        outerRadius={90}
                        label={({ name, percent }) => `${name.slice(0, 12)} ${(percent * 100).toFixed(0)}%`}
                      >
                        {["hsl(var(--primary))", "hsl(var(--accent))", "hsl(142 76% 36%)", "hsl(38 92% 50%)", "hsl(0 84% 60%)", "hsl(262 83% 58%)"].map((color, i) => (
                          <Cell key={i} fill={color} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>

                {/* Peak Hours */}
                <div className="bg-card border border-border rounded-2xl p-5 lg:col-span-2">
                  <h3 className="font-display font-semibold mb-4">Peak Booking Hours</h3>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={(() => {
                      const hours: Record<string, number> = {};
                      bookings.forEach((b: any) => {
                        const h = b.booking_time?.slice(0, 5) || "N/A";
                        hours[h] = (hours[h] || 0) + 1;
                      });
                      return Object.entries(hours)
                        .sort(([a], [b]) => a.localeCompare(b))
                        .map(([hour, count]) => ({ hour, count }));
                    })()}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                      <XAxis dataKey="hour" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} />
                      <YAxis allowDecimals={false} tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                      <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }} />
                      <Bar dataKey="count" fill="hsl(var(--accent))" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </TabsContent>

            {/* STATIONS TAB */}
            <TabsContent value="stations">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-display font-semibold">Manage Stations</h2>
                <Dialog open={dialogOpen} onOpenChange={(o) => { setDialogOpen(o); if (!o) resetForm(); }}>
                  <DialogTrigger asChild>
                    <Button size="sm" className="ev-gradient-bg text-primary-foreground gap-1.5">
                      <Plus className="w-4 h-4" /> Add Station
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>{editingStation ? "Edit Station" : "Add New Station"}</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleSubmit} className="space-y-4 mt-2">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <Label>Name *</Label>
                          <Input value={stationForm.name} onChange={(e) => setStationForm({ ...stationForm, name: e.target.value })} className="mt-1" />
                        </div>
                        <div>
                          <Label>Price / kWh (₹)</Label>
                          <Input type="number" step="0.01" value={stationForm.price_per_kwh} onChange={(e) => setStationForm({ ...stationForm, price_per_kwh: e.target.value })} className="mt-1" />
                        </div>
                      </div>
                      <div>
                        <Label>Address *</Label>
                        <Input value={stationForm.address} onChange={(e) => setStationForm({ ...stationForm, address: e.target.value })} className="mt-1" />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Latitude *</Label>
                          <Input type="number" step="any" value={stationForm.lat} onChange={(e) => setStationForm({ ...stationForm, lat: e.target.value })} className="mt-1" />
                        </div>
                        <div>
                          <Label>Longitude *</Label>
                          <Input type="number" step="any" value={stationForm.lng} onChange={(e) => setStationForm({ ...stationForm, lng: e.target.value })} className="mt-1" />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Total Points</Label>
                          <Input type="number" value={stationForm.total_points} onChange={(e) => setStationForm({ ...stationForm, total_points: e.target.value })} className="mt-1" />
                        </div>
                        <div>
                          <Label>Available Points</Label>
                          <Input type="number" value={stationForm.available_points} onChange={(e) => setStationForm({ ...stationForm, available_points: e.target.value })} className="mt-1" />
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch checked={stationForm.is_active} onCheckedChange={(v) => setStationForm({ ...stationForm, is_active: v })} />
                        <Label>Active</Label>
                      </div>
                      <Button type="submit" className="w-full ev-gradient-bg text-primary-foreground" disabled={upsertStation.isPending}>
                        {upsertStation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                        {editingStation ? "Update Station" : "Create Station"}
                      </Button>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>

              {stationsLoading ? (
                <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
              ) : (
                <div className="bg-card border border-border rounded-2xl overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Address</TableHead>
                        <TableHead className="text-center">Available</TableHead>
                        <TableHead className="text-center">Total</TableHead>
                        <TableHead className="text-center">₹/kWh</TableHead>
                        <TableHead className="text-center">Active</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {stations.map((s: any) => (
                        <TableRow key={s.id}>
                          <TableCell className="font-medium">{s.name}</TableCell>
                          <TableCell className="text-muted-foreground text-sm max-w-[200px] truncate">{s.address}</TableCell>
                          <TableCell className="text-center">
                            <Input
                              type="number"
                              min={0}
                              max={s.total_points}
                              defaultValue={s.available_points}
                              className="w-16 mx-auto text-center h-8"
                              onBlur={(e) => {
                                const val = parseInt(e.target.value);
                                if (!isNaN(val) && val !== s.available_points) {
                                  updateAvailability.mutate({ id: s.id, available_points: val });
                                }
                              }}
                            />
                          </TableCell>
                          <TableCell className="text-center">{s.total_points}</TableCell>
                          <TableCell className="text-center">₹{s.price_per_kwh}</TableCell>
                          <TableCell className="text-center">
                            <Switch
                              checked={s.is_active}
                              onCheckedChange={(v) => toggleActive.mutate({ id: s.id, is_active: v })}
                            />
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-1">
                              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(s)}>
                                <Pencil className="w-4 h-4" />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => deleteStation.mutate(s.id)}>
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </TabsContent>

            {/* PHOTOS TAB */}
            <TabsContent value="photos">
              <h2 className="text-lg font-display font-semibold mb-4">Station Photos</h2>
              <p className="text-sm text-muted-foreground mb-6">Upload photos for each station as an admin.</p>
              <div className="space-y-4">
                {stations.map((s: any) => (
                  <div key={s.id} className="bg-card border border-border rounded-2xl p-5">
                    <h3 className="font-display font-semibold mb-3">{s.name}</h3>
                    <StationPhotoUpload stationId={s.id} isAdmin />
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* BOOKINGS TAB */}
            <TabsContent value="bookings">
              <h2 className="text-lg font-display font-semibold mb-4">All Bookings</h2>
              {bookingsLoading ? (
                <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
              ) : bookings.length === 0 ? (
                <div className="bg-card border border-border rounded-2xl p-12 text-center text-muted-foreground">
                  No bookings yet.
                </div>
              ) : (
                <div className="bg-card border border-border rounded-2xl overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Station</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Time</TableHead>
                        <TableHead>Vehicle</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-muted-foreground text-xs">User ID</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {bookings.map((b: any) => (
                        <TableRow key={b.id}>
                          <TableCell className="font-medium">{b.charging_stations?.name ?? "—"}</TableCell>
                          <TableCell>{b.booking_date}</TableCell>
                          <TableCell>{b.booking_time}</TableCell>
                          <TableCell>{b.vehicle_type}</TableCell>
                          <TableCell>
                            <Badge variant={b.status === "confirmed" ? "default" : "secondary"}>
                              {b.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-xs text-muted-foreground font-mono truncate max-w-[120px]">{b.user_id}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </TabsContent>

            {/* MESSAGES TAB */}
            <TabsContent value="messages">
              <h2 className="text-lg font-display font-semibold mb-4">Contact Messages</h2>
              {messagesLoading ? (
                <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
              ) : messages.length === 0 ? (
                <div className="bg-card border border-border rounded-2xl p-12 text-center text-muted-foreground">
                  No messages yet.
                </div>
              ) : (
                <div className="space-y-3">
                  {messages.map((m: any) => (
                    <div key={m.id} className={`bg-card border rounded-2xl p-5 ${m.is_read ? 'border-border opacity-70' : 'border-primary/30'}`}>
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-display font-semibold">{m.name}</span>
                            {!m.is_read && <Badge variant="default" className="text-xs">New</Badge>}
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">{m.email}</p>
                          <p className="text-sm">{m.message}</p>
                          <p className="text-xs text-muted-foreground mt-2">
                            {new Date(m.created_at).toLocaleString()}
                          </p>
                        </div>
                        <div className="flex gap-1 shrink-0">
                          {!m.is_read && (
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => markRead.mutate(m.id)}>
                              <Eye className="w-4 h-4" />
                            </Button>
                          )}
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => deleteMessage.mutate(m.id)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </TabsContent>

            {/* CLOUD TAB */}
            <TabsContent value="cloud">
              <div className="space-y-6">
                {/* User Management */}
                <div>
                  <div className="flex items-center gap-2 mb-4">
                    <Users className="w-5 h-5 text-primary" />
                    <h2 className="text-lg font-display font-semibold">Registered Users</h2>
                    <Badge variant="secondary" className="ml-auto">{profiles.length} users</Badge>
                  </div>
                  {profilesLoading ? (
                    <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
                  ) : (
                    <div className="bg-card border border-border rounded-2xl overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Display Name</TableHead>
                            <TableHead>Phone</TableHead>
                            <TableHead>Joined</TableHead>
                            <TableHead>User ID</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {profiles.map((p: any) => (
                            <TableRow key={p.id}>
                              <TableCell className="font-medium">{p.display_name || "—"}</TableCell>
                              <TableCell className="text-muted-foreground">{p.phone || "—"}</TableCell>
                              <TableCell className="text-muted-foreground text-sm">
                                {new Date(p.created_at).toLocaleDateString()}
                              </TableCell>
                              <TableCell className="text-xs text-muted-foreground font-mono truncate max-w-[120px]">
                                {p.user_id}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </div>

                {/* Database Overview */}
                <div>
                  <div className="flex items-center gap-2 mb-4">
                    <Database className="w-5 h-5 text-primary" />
                    <h2 className="text-lg font-display font-semibold">Database Overview</h2>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {[
                      { label: "Stations", table: "charging_stations", icon: MapPin },
                      { label: "Bookings", table: "bookings", icon: CalendarCheck },
                      { label: "Profiles", table: "profiles", icon: Users },
                      { label: "Reviews", table: "station_reviews", icon: MessageSquare },
                      { label: "Photos", table: "station_photos", icon: ImagePlus },
                      { label: "Favorites", table: "favorite_stations", icon: HardDrive },
                      { label: "Messages", table: "contact_messages", icon: MessageSquare },
                      { label: "User Roles", table: "user_roles", icon: Shield },
                    ].map(({ label, table, icon: Icon }) => (
                      <div key={table} className="bg-card border border-border rounded-2xl p-4 flex flex-col items-center gap-2">
                        <Icon className="w-5 h-5 text-primary" />
                        <p className="text-2xl font-display font-bold">{tableCounts[table] ?? "—"}</p>
                        <p className="text-xs text-muted-foreground">{label}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Storage Info */}
                <div>
                  <div className="flex items-center gap-2 mb-4">
                    <HardDrive className="w-5 h-5 text-primary" />
                    <h2 className="text-lg font-display font-semibold">Storage</h2>
                  </div>
                  <div className="bg-card border border-border rounded-2xl p-5">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">station-photos</p>
                        <p className="text-sm text-muted-foreground">Public bucket for station images</p>
                      </div>
                      <Badge variant="outline">Public</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">
                      {tableCounts["station_photos"] ?? 0} photos uploaded
                    </p>
                  </div>
                </div>

                {/* Security Overview */}
                <div>
                  <div className="flex items-center gap-2 mb-4">
                    <Shield className="w-5 h-5 text-primary" />
                    <h2 className="text-lg font-display font-semibold">Security</h2>
                  </div>
                  <div className="bg-card border border-border rounded-2xl p-5 space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-sm">Row Level Security (RLS)</p>
                      <Badge variant="outline" className="text-primary border-primary/30">Enabled on all tables</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <p className="text-sm">Authentication</p>
                      <Badge variant="outline" className="text-primary border-primary/30">Active</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <p className="text-sm">Admin role check</p>
                      <Badge variant="outline" className="text-primary border-primary/30">Security Definer</Badge>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
};

export default AdminPage;
