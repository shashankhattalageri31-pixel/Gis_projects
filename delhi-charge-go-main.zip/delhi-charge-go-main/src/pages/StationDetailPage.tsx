import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  MapPin,
  Star,
  Heart,
  Zap,
  IndianRupee,
  Loader2,
  ArrowLeft,
  Send,
} from "lucide-react";
import StationPhotoGallery from "@/components/StationPhotoGallery";
import StationPhotoUpload from "@/components/StationPhotoUpload";

const StationDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");

  // Fetch station
  const { data: station, isLoading } = useQuery({
    queryKey: ["station", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("charging_stations")
        .select("*")
        .eq("id", id!)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!id,
  });

  // Fetch reviews
  const { data: reviews = [] } = useQuery({
    queryKey: ["reviews", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("station_reviews" as any)
        .select("*")
        .eq("station_id", id!)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as any[];
    },
    enabled: !!id,
  });

  // Check if favorited
  const { data: isFavorited } = useQuery({
    queryKey: ["favorite", id, user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("favorite_stations" as any)
        .select("id")
        .eq("station_id", id!)
        .eq("user_id", user!.id)
        .maybeSingle();
      return !!data;
    },
    enabled: !!id && !!user,
  });

  // Check if user already reviewed
  const { data: userReview } = useQuery({
    queryKey: ["user-review", id, user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("station_reviews" as any)
        .select("*")
        .eq("station_id", id!)
        .eq("user_id", user!.id)
        .maybeSingle();
      return data as any;
    },
    enabled: !!id && !!user,
  });

  // Toggle favorite
  const toggleFav = useMutation({
    mutationFn: async () => {
      if (isFavorited) {
        await supabase
          .from("favorite_stations" as any)
          .delete()
          .eq("station_id", id!)
          .eq("user_id", user!.id);
      } else {
        await supabase
          .from("favorite_stations" as any)
          .insert({ station_id: id!, user_id: user!.id } as any);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["favorite", id, user?.id] });
      toast.success(isFavorited ? "Removed from favorites" : "Added to favorites!");
    },
  });

  // Submit review
  const submitReview = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("station_reviews" as any)
        .insert({
          station_id: id!,
          user_id: user!.id,
          rating,
          comment: comment.trim() || null,
        } as any);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["reviews", id] });
      queryClient.invalidateQueries({ queryKey: ["user-review", id, user?.id] });
      setComment("");
      toast.success("Review submitted!");
    },
    onError: (err: Error) => toast.error(err.message),
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-24">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!station) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-24">
        <p className="text-muted-foreground">Station not found.</p>
      </div>
    );
  }

  const avgRating =
    reviews.length > 0
      ? (reviews.reduce((sum: number, r: any) => sum + r.rating, 0) / reviews.length).toFixed(1)
      : station.rating;

  return (
    <div className="pt-24 pb-16 min-h-screen">
      <div className="container mx-auto px-4 max-w-3xl">
        <Link to="/stations" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-6">
          <ArrowLeft className="w-4 h-4" /> Back to Stations
        </Link>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          {/* Station Header */}
          <div className="bg-card border border-border rounded-2xl p-6 mb-6">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h1 className="text-2xl font-display font-bold mb-1">{station.name}</h1>
                <p className="text-muted-foreground flex items-center gap-1 text-sm">
                  <MapPin className="w-4 h-4" /> {station.address}
                </p>
              </div>
              {user && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => toggleFav.mutate()}
                  className={isFavorited ? "text-red-500" : "text-muted-foreground"}
                >
                  <Heart className={`w-5 h-5 ${isFavorited ? "fill-current" : ""}`} />
                </Button>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-5">
              <div className="bg-muted/50 rounded-xl p-3 text-center">
                <Zap className="w-5 h-5 mx-auto mb-1 text-primary" />
                <p className="text-xs text-muted-foreground">Available</p>
                <p className="font-display font-bold">{station.available_points}/{station.total_points}</p>
              </div>
              <div className="bg-muted/50 rounded-xl p-3 text-center">
                <IndianRupee className="w-5 h-5 mx-auto mb-1 text-primary" />
                <p className="text-xs text-muted-foreground">Price</p>
                <p className="font-display font-bold">₹{station.price_per_kwh}/kWh</p>
              </div>
              <div className="bg-muted/50 rounded-xl p-3 text-center">
                <Star className="w-5 h-5 mx-auto mb-1 text-yellow-500" />
                <p className="text-xs text-muted-foreground">Rating</p>
                <p className="font-display font-bold">{avgRating}</p>
              </div>
              <div className="bg-muted/50 rounded-xl p-3 text-center">
                <p className="text-xs text-muted-foreground mt-1">Charger Types</p>
                <div className="flex flex-wrap gap-1 justify-center mt-1">
                  {station.charger_type.map((t: string) => (
                    <Badge key={t} variant="secondary" className="text-xs">{t}</Badge>
                  ))}
                </div>
              </div>
            </div>

            {station.amenities.length > 0 && (
              <div className="mt-4">
                <p className="text-sm font-medium mb-2">Amenities</p>
                <div className="flex flex-wrap gap-1.5">
                  {station.amenities.map((a: string) => (
                    <Badge key={a} variant="outline" className="text-xs">{a}</Badge>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-5">
              <Link to={`/booking?station=${station.id}`}>
                <Button className="ev-gradient-bg text-primary-foreground">Book a Slot</Button>
              </Link>
            </div>
          </div>

          {/* Photo Gallery */}
          <StationPhotoGallery stationId={station.id} />

          {/* Write Review */}
          {user && !userReview && (
            <div className="bg-card border border-border rounded-2xl p-6 mb-6">
              <h2 className="font-display font-semibold mb-3">Write a Review</h2>
              <div className="flex gap-1 mb-3">
                {[1, 2, 3, 4, 5].map((s) => (
                  <button key={s} onClick={() => setRating(s)} type="button">
                    <Star
                      className={`w-6 h-6 transition-colors ${
                        s <= rating ? "text-yellow-500 fill-yellow-500" : "text-muted-foreground"
                      }`}
                    />
                  </button>
                ))}
              </div>
              <Textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Share your experience (optional)"
                rows={3}
                className="mb-3"
              />
              <div className="mb-3">
                <StationPhotoUpload stationId={station.id} />
              </div>
              <Button
                onClick={() => submitReview.mutate()}
                disabled={submitReview.isPending}
                className="ev-gradient-bg text-primary-foreground gap-1.5"
              >
                {submitReview.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                Submit Review
              </Button>
            </div>
          )}

          {userReview && (
            <div className="bg-card border border-primary/20 rounded-2xl p-6 mb-6">
              <p className="text-sm text-muted-foreground">You already reviewed this station</p>
              <div className="flex gap-0.5 mt-1">
                {[1, 2, 3, 4, 5].map((s) => (
                  <Star key={s} className={`w-4 h-4 ${s <= userReview.rating ? "text-yellow-500 fill-yellow-500" : "text-muted-foreground"}`} />
                ))}
              </div>
              {userReview.comment && <p className="text-sm mt-2">{userReview.comment}</p>}
            </div>
          )}

          {/* Reviews List */}
          <div>
            <h2 className="font-display font-semibold mb-4">
              Reviews ({reviews.length})
            </h2>
            {reviews.length === 0 ? (
              <p className="text-sm text-muted-foreground">No reviews yet. Be the first!</p>
            ) : (
              <div className="space-y-3">
                {reviews.map((r: any) => (
                  <div key={r.id} className="bg-card border border-border rounded-xl p-4">
                    <div className="flex items-center gap-2 mb-1">
                      <Avatar className="w-7 h-7">
                        <AvatarFallback className="text-xs bg-muted">U</AvatarFallback>
                      </Avatar>
                      <div className="flex gap-0.5">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <Star key={s} className={`w-3.5 h-3.5 ${s <= r.rating ? "text-yellow-500 fill-yellow-500" : "text-muted-foreground"}`} />
                        ))}
                      </div>
                      <span className="text-xs text-muted-foreground ml-auto">
                        {new Date(r.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    {r.comment && <p className="text-sm mt-1">{r.comment}</p>}
                  </div>
                ))}
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default StationDetailPage;
