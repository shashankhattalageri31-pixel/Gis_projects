import { useEffect, useRef, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { useStations } from "@/hooks/useStations";
import { Layers, Navigation, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

const MAP_TILES = {
  road: {
    url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    attr: '&copy; <a href="https://openstreetmap.org">OpenStreetMap</a>',
  },
  dark: {
    url: "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
    attr: '&copy; <a href="https://carto.com">CARTO</a>',
  },
  satellite: {
    url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    attr: "Tiles &copy; Esri",
  },
};

type TileKey = keyof typeof MAP_TILES;

const createMarkerIcon = (available: number) => {
  const color = available > 2 ? "#22c55e" : available > 0 ? "#f59e0b" : "#ef4444";
  return L.divIcon({
    className: "custom-marker",
    html: `<div style="width:36px;height:36px;border-radius:50%;background:${color};display:flex;align-items:center;justify-content:center;color:white;font-weight:bold;font-size:14px;box-shadow:0 2px 8px ${color}66;border:3px solid white;">⚡</div>`,
    iconSize: [36, 36],
    iconAnchor: [18, 18],
    popupAnchor: [0, -20],
  });
};

const fetchRoute = async (
  from: [number, number],
  to: [number, number]
): Promise<{ coords: [number, number][]; distKm: number; timeMin: number } | null> => {
  try {
    const url = `https://router.project-osrm.org/route/v1/driving/${from[1]},${from[0]};${to[1]},${to[0]}?overview=full&geometries=geojson`;
    const res = await fetch(url);
    const json = await res.json();
    if (json.code !== "Ok" || !json.routes?.length) return null;
    const route = json.routes[0];
    const coords: [number, number][] = route.geometry.coordinates.map(
      (c: [number, number]) => [c[1], c[0]] as [number, number]
    );
    return {
      coords,
      distKm: +(route.distance / 1000).toFixed(1),
      timeMin: Math.round(route.duration / 60),
    };
  } catch {
    return null;
  }
};

const MapPage = () => {
  const { data: stations = [] } = useStations();
  const mapRef = useRef<L.Map | null>(null);
  const tileRef = useRef<L.TileLayer | null>(null);
  const routeRef = useRef<L.Polyline | null>(null);
  const markersRef = useRef<L.Marker[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);
  const [activeLayer, setActiveLayer] = useState<TileKey>("road");
  const [showLayerMenu, setShowLayerMenu] = useState(false);
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null);
  const [routing, setRouting] = useState(false);

  // Init map
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;
    const map = L.map(containerRef.current).setView([28.6139, 77.209], 12);
    mapRef.current = map;
    const tile = L.tileLayer(MAP_TILES.road.url, { attribution: MAP_TILES.road.attr });
    tile.addTo(map);
    tileRef.current = tile;

    navigator.geolocation?.getCurrentPosition(
      (pos) => setUserLocation([pos.coords.latitude, pos.coords.longitude]),
      () => {}
    );

    return () => { map.remove(); mapRef.current = null; };
  }, []);

  // Add markers when stations load
  useEffect(() => {
    if (!mapRef.current) return;
    markersRef.current.forEach((m) => m.remove());
    markersRef.current = [];

    stations.forEach((s) => {
      const marker = L.marker([s.lat, s.lng], { icon: createMarkerIcon(s.available_points) });
      marker.addTo(mapRef.current!);
      marker.bindPopup(`
        <div style="font-family:Inter,sans-serif;min-width:220px;">
          <h3 style="font-weight:700;font-size:15px;margin:0 0 4px;">${s.name}</h3>
          <p style="color:#666;font-size:12px;margin:0 0 8px;">${s.address}</p>
          <div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px;">
            ${s.charger_type.map((t) => `<span style="font-size:11px;background:#f0f0f0;padding:2px 6px;border-radius:4px;">${t}</span>`).join("")}
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
            <span style="font-size:13px;"><strong>${s.available_points}</strong>/${s.total_points} available</span>
            <span style="font-weight:700;color:#22c55e;">₹${s.price_per_kwh}/kWh</span>
          </div>
          <button onclick="window.getDirections(${s.lat},${s.lng})" style="width:100%;padding:8px;background:linear-gradient(135deg,#22c55e,#0ea5e9);color:white;border:none;border-radius:8px;cursor:pointer;font-weight:600;font-size:13px;">
            🧭 Get Directions
          </button>
        </div>
      `);
      markersRef.current.push(marker);
    });
  }, [stations]);

  // Directions handler with OSRM routing
  useEffect(() => {
    (window as any).getDirections = async (lat: number, lng: number) => {
      if (!mapRef.current) return;
      if (userLocation) {
        setRouting(true);
        // Remove old route
        if (routeRef.current) mapRef.current.removeLayer(routeRef.current);

        const result = await fetchRoute(userLocation, [lat, lng]);

        if (result) {
          const route = L.polyline(result.coords, {
            color: "#22c55e",
            weight: 5,
            opacity: 0.85,
          });
          route.addTo(mapRef.current);
          routeRef.current = route;
          mapRef.current.fitBounds(route.getBounds(), { padding: [50, 50] });

          L.popup()
            .setLatLng(result.coords[Math.floor(result.coords.length / 2)])
            .setContent(
              `<div style="text-align:center;font-family:Inter,sans-serif;">
                <strong>${result.distKm} km</strong><br/>
                <span style="color:#666;">~${result.timeMin} min drive</span>
              </div>`
            )
            .openOn(mapRef.current);
        } else {
          // Fallback to straight line
          const route = L.polyline([userLocation, [lat, lng]], {
            color: "#22c55e",
            weight: 4,
            dashArray: "10 6",
          });
          route.addTo(mapRef.current);
          routeRef.current = route;
          mapRef.current.fitBounds(route.getBounds(), { padding: [50, 50] });
          const from = L.latLng(userLocation[0], userLocation[1]);
          const to = L.latLng(lat, lng);
          const dist = (from.distanceTo(to) / 1000).toFixed(1);
          L.popup()
            .setLatLng([(userLocation[0] + lat) / 2, (userLocation[1] + lng) / 2])
            .setContent(
              `<div style="text-align:center;font-family:Inter,sans-serif;">
                <strong>${dist} km</strong> (straight line)<br/>
                <span style="color:#666;">Route unavailable</span>
              </div>`
            )
            .openOn(mapRef.current);
        }
        setRouting(false);
      } else {
        window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, "_blank");
      }
    };
  }, [userLocation]);

  // Layer switching
  useEffect(() => {
    if (!mapRef.current || !tileRef.current) return;
    mapRef.current.removeLayer(tileRef.current);
    const t = MAP_TILES[activeLayer];
    const newTile = L.tileLayer(t.url, { attribution: t.attr });
    newTile.addTo(mapRef.current);
    tileRef.current = newTile;
  }, [activeLayer]);

  const locateUser = () => {
    if (!mapRef.current) return;
    navigator.geolocation?.getCurrentPosition((pos) => {
      const loc: [number, number] = [pos.coords.latitude, pos.coords.longitude];
      setUserLocation(loc);
      mapRef.current?.setView(loc, 14);
      L.circleMarker(loc, { radius: 10, color: "#0ea5e9", fillColor: "#0ea5e9", fillOpacity: 0.5 }).addTo(mapRef.current!);
    });
  };

  return (
    <div className="pt-16 h-screen flex flex-col">
      <div className="absolute top-20 right-4 z-[1000] flex flex-col gap-2">
        {routing && (
          <div className="bg-card border border-border rounded-lg shadow-lg px-3 py-2 flex items-center gap-2 text-sm">
            <Loader2 className="w-4 h-4 animate-spin text-primary" />
            Calculating route…
          </div>
        )}
        <div className="relative">
          <Button size="icon" className="bg-card border border-border shadow-lg text-foreground hover:bg-muted" onClick={() => setShowLayerMenu(!showLayerMenu)}>
            <Layers className="w-4 h-4" />
          </Button>
          {showLayerMenu && (
            <div className="absolute right-12 top-0 bg-card border border-border rounded-lg shadow-xl p-2 min-w-[140px]">
              {(Object.keys(MAP_TILES) as TileKey[]).map((key) => (
                <button key={key} onClick={() => { setActiveLayer(key); setShowLayerMenu(false); }}
                  className={`block w-full text-left px-3 py-2 text-sm rounded-md capitalize transition-colors ${activeLayer === key ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted text-foreground"}`}>
                  {key === "road" ? "Road Map" : key === "dark" ? "Dark Theme" : "Satellite"}
                </button>
              ))}
            </div>
          )}
        </div>
        <Button size="icon" className="bg-card border border-border shadow-lg text-foreground hover:bg-muted" onClick={locateUser}>
          <Navigation className="w-4 h-4" />
        </Button>
      </div>
      <div ref={containerRef} className="flex-1 w-full" />
    </div>
  );
};

export default MapPage;
