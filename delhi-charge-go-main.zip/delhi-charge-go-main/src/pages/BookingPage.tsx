import { useState } from "react";
import { useStations } from "@/hooks/useStations";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CalendarDays, CheckCircle, LogIn } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import { Link } from "react-router-dom";

const BookingPage = () => {
  const { user } = useAuth();
  const { data: stations = [] } = useStations();
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    vehicleType: "",
    stationId: "",
    date: "",
    time: "",
  });

  const selectedStation = stations.find((s) => s.id === form.stationId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast.error("Please login to book a slot");
      return;
    }
    if (!form.vehicleType || !form.stationId || !form.date || !form.time) {
      toast.error("Please fill in all fields");
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.from("bookings").insert({
        user_id: user.id,
        station_id: form.stationId,
        vehicle_type: form.vehicleType,
        booking_date: form.date,
        booking_time: form.time,
      });
      if (error) throw error;
      setSubmitted(true);
      toast.success("Booking confirmed!");
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="pt-24 pb-16 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-display font-bold mb-4">Login Required</h2>
          <p className="text-muted-foreground mb-6">Please sign in to book a charging slot.</p>
          <Link to="/auth">
            <Button className="ev-gradient-bg text-primary-foreground">
              <LogIn className="w-4 h-4 mr-2" /> Sign In
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 pb-16 min-h-screen">
      <div className="container mx-auto px-4 max-w-2xl">
        <div className="mb-8 text-center">
          <h1 className="text-3xl md:text-4xl font-display font-bold mb-2">
            Book a <span className="ev-gradient-text">Charging Slot</span>
          </h1>
          <p className="text-muted-foreground">Reserve your charging spot in advance</p>
        </div>

        <AnimatePresence mode="wait">
          {submitted ? (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-card border border-border rounded-2xl p-12 text-center"
            >
              <div className="w-20 h-20 mx-auto rounded-full ev-gradient-bg flex items-center justify-center mb-6">
                <CheckCircle className="w-10 h-10 text-primary-foreground" />
              </div>
              <h2 className="text-2xl font-display font-bold mb-2">Booking Confirmed!</h2>
              <p className="text-muted-foreground mb-6">
                Your charging slot at <strong>{selectedStation?.name}</strong> on {form.date} at {form.time} has been reserved.
              </p>
              <Button onClick={() => { setSubmitted(false); setForm({ vehicleType: "", stationId: "", date: "", time: "" }); }} variant="outline">
                Book Another
              </Button>
            </motion.div>
          ) : (
            <motion.form
              key="form"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              onSubmit={handleSubmit}
              className="bg-card border border-border rounded-2xl p-8 space-y-5"
            >
              <div>
                <Label htmlFor="vehicle">Vehicle Type</Label>
                <Input id="vehicle" value={form.vehicleType} onChange={(e) => setForm({ ...form, vehicleType: e.target.value })} placeholder="e.g. Tata Nexon EV" className="mt-1.5" />
              </div>

              <div>
                <Label htmlFor="station">Charging Station</Label>
                <select
                  id="station"
                  value={form.stationId}
                  onChange={(e) => setForm({ ...form, stationId: e.target.value })}
                  className="w-full mt-1.5 bg-muted text-foreground px-3 py-2 rounded-lg text-sm border border-input outline-none"
                >
                  <option value="">Select a station</option>
                  {stations.map((s) => (
                    <option key={s.id} value={s.id}>{s.name} ({s.available_points} available)</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <Label htmlFor="date">Date</Label>
                  <Input id="date" type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className="mt-1.5" />
                </div>
                <div>
                  <Label htmlFor="time">Time</Label>
                  <Input id="time" type="time" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} className="mt-1.5" />
                </div>
              </div>

              <Button type="submit" size="lg" className="w-full ev-gradient-bg text-primary-foreground py-6 text-lg" disabled={loading}>
                <CalendarDays className="w-5 h-5 mr-2" />
                {loading ? "Booking..." : "Confirm Booking"}
              </Button>
            </motion.form>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default BookingPage;
