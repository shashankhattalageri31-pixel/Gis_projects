import { Leaf, Car, Battery, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

const benefits = [
  { icon: Leaf, title: "Zero Emissions", desc: "EVs produce no tailpipe emissions, reducing Delhi's air pollution significantly." },
  { icon: Car, title: "Lower Running Cost", desc: "Electricity costs ₹1-2/km vs ₹5-7/km for petrol. Save up to 70% on fuel." },
  { icon: Battery, title: "Growing Infrastructure", desc: "Delhi now has 500+ public chargers with plans to add 1000+ by 2027." },
  { icon: TrendingUp, title: "Government Support", desc: "Delhi EV Policy offers purchase subsidies, road tax waiver, and free parking." },
];

const AboutPage = () => (
  <div className="pt-24 pb-16 min-h-screen">
    <div className="container mx-auto px-4 max-w-4xl">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl md:text-4xl font-display font-bold mb-4">
          About <span className="ev-gradient-text">Delhi EV Charge</span>
        </h1>
        <p className="text-lg text-muted-foreground mb-12 max-w-2xl">
          We're on a mission to accelerate Delhi's transition to electric vehicles by making charging infrastructure accessible, affordable, and easy to find.
        </p>
      </motion.div>

      <div className="mb-16">
        <h2 className="text-2xl font-display font-bold mb-6">EV Adoption in Delhi</h2>
        <div className="bg-card border border-border rounded-2xl p-8 space-y-4 text-muted-foreground leading-relaxed">
          <p>Delhi has emerged as India's leading EV capital, with over 90,000 electric vehicles registered as of 2025. The Delhi EV Policy, one of India's most progressive, has driven adoption through purchase incentives, road tax waivers, and investment in charging infrastructure.</p>
          <p>The Delhi government aims for 25% of all new vehicle registrations to be electric by 2027. With FAME-II subsidies and state-level incentives, the total cost of ownership for EVs is now lower than comparable ICE vehicles.</p>
          <p>Public charging infrastructure has grown 5x since 2022, with major players like Tata Power, EESL, ChargeZone, and Fortum deploying stations across the city. Delhi EV Charge aggregates all these stations to help you find the nearest charger instantly.</p>
        </div>
      </div>

      <h2 className="text-2xl font-display font-bold mb-6">Why Go Electric?</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {benefits.map((b, i) => (
          <motion.div
            key={b.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="bg-card border border-border rounded-2xl p-6"
          >
            <div className="w-12 h-12 rounded-xl ev-gradient-bg flex items-center justify-center mb-4">
              <b.icon className="w-6 h-6 text-primary-foreground" />
            </div>
            <h3 className="font-display font-semibold text-lg mb-2">{b.title}</h3>
            <p className="text-muted-foreground text-sm">{b.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </div>
);

export default AboutPage;
