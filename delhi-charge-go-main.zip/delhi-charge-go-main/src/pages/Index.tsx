import { Link } from "react-router-dom";
import { Zap, MapPin, Battery, BatteryCharging, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import heroBg from "@/assets/hero-bg.jpg";
import { useStations } from "@/hooks/useStations";

const Index = () => {
  const { data: stations = [] } = useStations();

  const totalAvailable = stations.reduce((sum, s) => sum + s.available_points, 0);
  const fastChargers = stations.filter((s) => s.charger_type.includes("Fast") || s.charger_type.includes("CCS")).length;

  const stats = [
    { icon: MapPin, value: `${stations.length}+`, label: "Charging Stations" },
    { icon: BatteryCharging, value: `${fastChargers}+`, label: "Fast Chargers" },
    { icon: Battery, value: `${totalAvailable}+`, label: "Available Now" },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${heroBg})` }} />
        <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/50 to-background" />

        <div className="relative z-10 container mx-auto px-4 text-center pt-16">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/20 rounded-full px-4 py-1.5 mb-6">
              <Zap className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">Delhi's #1 EV Charging Network</span>
            </div>

            <h1 className="text-4xl sm:text-5xl md:text-7xl font-display font-bold mb-6 leading-tight">
              Powering Delhi's<br />
              <span className="ev-gradient-text">Electric Future</span>
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
              Find, navigate, and book EV charging stations across Delhi.
              Fast chargers, real-time availability, and seamless booking.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/map">
                <Button size="lg" className="ev-gradient-bg text-primary-foreground px-8 py-6 text-lg ev-glow hover:opacity-90 transition-opacity">
                  <MapPin className="w-5 h-5 mr-2" /> Find Nearest Station
                </Button>
              </Link>
              <Link to="/stations">
                <Button variant="outline" size="lg" className="px-8 py-6 text-lg border-primary/30 hover:bg-primary/5">
                  View All Stations <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-20 bg-card">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {stats.map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="text-center p-8 rounded-2xl bg-ev-surface border border-border"
              >
                <div className="w-14 h-14 mx-auto rounded-xl ev-gradient-bg flex items-center justify-center mb-4">
                  <stat.icon className="w-7 h-7 text-primary-foreground" />
                </div>
                <div className="text-4xl font-display font-bold ev-gradient-text mb-1">{stat.value}</div>
                <div className="text-muted-foreground">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Stations */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-3">
              Popular <span className="ev-gradient-text">Charging Stations</span>
            </h2>
            <p className="text-muted-foreground max-w-lg mx-auto">
              Top-rated stations across Delhi with fast charging and great amenities
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {stations.slice(0, 3).map((station, i) => (
              <motion.div
                key={station.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-card border border-border rounded-2xl p-6 hover:border-primary/30 transition-colors"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-10 h-10 rounded-lg ev-gradient-bg flex items-center justify-center">
                    <Zap className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${
                    station.available_points > 2 ? "bg-primary/10 text-primary" : "bg-destructive/10 text-destructive"
                  }`}>
                    {station.available_points} / {station.total_points} Available
                  </span>
                </div>
                <h3 className="font-display font-semibold text-lg mb-1">{station.name}</h3>
                <p className="text-sm text-muted-foreground mb-3">{station.address}</p>
                <div className="flex flex-wrap gap-1.5 mb-4">
                  {station.charger_type.map((type) => (
                    <span key={type} className="text-xs bg-muted px-2 py-0.5 rounded-md text-muted-foreground">{type}</span>
                  ))}
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-display font-bold text-primary">₹{station.price_per_kwh}/kWh</span>
                  <Link to="/map">
                    <Button size="sm" variant="outline" className="border-primary/30 text-primary hover:bg-primary/5">
                      <MapPin className="w-3.5 h-3.5 mr-1" /> Directions
                    </Button>
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
