import { useState, useMemo } from "react";
import { useStations } from "@/hooks/useStations";
import { Zap, MapPin, Star, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";

const StationsPage = () => {
  const { data: stations = [], isLoading } = useStations();
  const [filterType, setFilterType] = useState<string>("all");
  const [filterAvailable, setFilterAvailable] = useState(false);
  const [maxPrice, setMaxPrice] = useState(15);

  const filtered = useMemo(() => {
    return stations.filter((s) => {
      if (filterType !== "all" && !s.charger_type.includes(filterType)) return false;
      if (filterAvailable && s.available_points === 0) return false;
      if (s.price_per_kwh > maxPrice) return false;
      return true;
    });
  }, [stations, filterType, filterAvailable, maxPrice]);

  if (isLoading) {
    return (
      <div className="pt-24 pb-16 min-h-screen flex items-center justify-center">
        <div className="text-muted-foreground">Loading stations...</div>
      </div>
    );
  }

  return (
    <div className="pt-24 pb-16 min-h-screen">
      <div className="container mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-display font-bold mb-2">
            Charging <span className="ev-gradient-text">Stations</span>
          </h1>
          <p className="text-muted-foreground">Browse all EV charging stations in Delhi</p>
        </div>

        {/* Filters */}
        <div className="bg-card border border-border rounded-2xl p-4 mb-8 flex flex-wrap gap-4 items-center">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="bg-muted text-foreground px-3 py-2 rounded-lg text-sm border-0 outline-none"
          >
            <option value="all">All Types</option>
            <option value="Fast">Fast</option>
            <option value="CCS">CCS</option>
            <option value="Type2">Type 2</option>
            <option value="Slow">Slow</option>
          </select>
          <label className="flex items-center gap-2 text-sm cursor-pointer">
            <input
              type="checkbox"
              checked={filterAvailable}
              onChange={(e) => setFilterAvailable(e.target.checked)}
              className="accent-primary"
            />
            Available only
          </label>
          <div className="flex items-center gap-2 text-sm">
            <span className="text-muted-foreground">Max ₹</span>
            <input
              type="range"
              min={5}
              max={15}
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="accent-primary w-24"
            />
            <span className="font-medium">{maxPrice}/kWh</span>
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((station, i) => (
            <motion.div
              key={station.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="bg-card border border-border rounded-2xl p-6 hover:border-primary/30 transition-all hover:shadow-lg cursor-pointer"
              onClick={() => window.location.href = `/station/${station.id}`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-lg ev-gradient-bg flex items-center justify-center shrink-0">
                  <Zap className="w-5 h-5 text-primary-foreground" />
                </div>
                <div className="flex items-center gap-1">
                  <Star className="w-3.5 h-3.5 text-yellow-500 fill-yellow-500" />
                  <span className="text-sm font-medium">{station.rating}</span>
                </div>
              </div>

              <h3 className="font-display font-semibold mb-1">{station.name}</h3>
              <p className="text-sm text-muted-foreground mb-3 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5" /> {station.address}
              </p>

              <div className="flex flex-wrap gap-1.5 mb-3">
                {station.charger_type.map((type) => (
                  <span key={type} className="text-xs bg-muted px-2 py-0.5 rounded-md text-muted-foreground">
                    {type}
                  </span>
                ))}
              </div>

              <div className="flex flex-wrap gap-1.5 mb-4">
                {station.amenities.map((a) => (
                  <span key={a} className="text-xs bg-primary/5 text-primary px-2 py-0.5 rounded-md">
                    {a}
                  </span>
                ))}
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-border">
                <div>
                  <span className={`text-sm font-medium ${station.available_points > 2 ? "text-primary" : "text-destructive"}`}>
                    {station.available_points}/{station.total_points} available
                  </span>
                  <span className="text-sm text-muted-foreground ml-3">₹{station.price_per_kwh}/kWh</span>
                </div>
                <Link to={`/station/${station.id}`}>
                  <Button size="sm" variant="outline" className="text-xs mr-1">
                    Details
                  </Button>
                </Link>
                <Link to={`/booking?station=${station.id}`}>
                  <Button size="sm" className="ev-gradient-bg text-primary-foreground text-xs">
                    Book
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-20 text-muted-foreground">
            No stations match your filters. Try adjusting them.
          </div>
        )}
      </div>
    </div>
  );
};

export default StationsPage;
