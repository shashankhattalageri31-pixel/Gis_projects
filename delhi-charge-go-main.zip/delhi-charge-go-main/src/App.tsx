import { useState, useEffect } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Index from "./pages/Index";
import MapPage from "./pages/MapPage";
import StationsPage from "./pages/StationsPage";
import BookingPage from "./pages/BookingPage";
import AboutPage from "./pages/AboutPage";
import ContactPage from "./pages/ContactPage";
import AuthPage from "./pages/AuthPage";
import MyBookingsPage from "./pages/MyBookingsPage";
import AdminPage from "./pages/AdminPage";
import ProfilePage from "./pages/ProfilePage";
import StationDetailPage from "./pages/StationDetailPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => {
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", darkMode);
  }, [darkMode]);

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Navbar darkMode={darkMode} toggleDarkMode={() => setDarkMode(!darkMode)} />
            <Routes>
              <Route path="/" element={<><Index /><Footer /></>} />
              <Route path="/map" element={<MapPage />} />
              <Route path="/stations" element={<><StationsPage /><Footer /></>} />
              <Route path="/booking" element={<><BookingPage /><Footer /></>} />
              <Route path="/about" element={<><AboutPage /><Footer /></>} />
              <Route path="/contact" element={<><ContactPage /><Footer /></>} />
              <Route path="/auth" element={<><AuthPage /><Footer /></>} />
              <Route path="/my-bookings" element={<><MyBookingsPage /><Footer /></>} />
              <Route path="/admin" element={<><AdminPage /><Footer /></>} />
              <Route path="/profile" element={<><ProfilePage /><Footer /></>} />
              <Route path="/station/:id" element={<><StationDetailPage /><Footer /></>} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
};

export default App;
