import { Zap } from "lucide-react";
import { Link } from "react-router-dom";

const Footer = () => (
  <footer className="bg-card border-t border-border py-12">
    <div className="container mx-auto px-4">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <div>
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-lg ev-gradient-bg flex items-center justify-center">
              <Zap className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-display font-bold ev-gradient-text">Delhi EV Charge</span>
          </div>
          <p className="text-sm text-muted-foreground">
            Powering Delhi's electric future, one charge at a time.
          </p>
        </div>
        <div>
          <h4 className="font-display font-semibold mb-3">Quick Links</h4>
          <div className="flex flex-col gap-2 text-sm text-muted-foreground">
            <Link to="/map" className="hover:text-primary transition-colors">Find Stations</Link>
            <Link to="/stations" className="hover:text-primary transition-colors">Station List</Link>
            <Link to="/booking" className="hover:text-primary transition-colors">Book a Slot</Link>
          </div>
        </div>
        <div>
          <h4 className="font-display font-semibold mb-3">Information</h4>
          <div className="flex flex-col gap-2 text-sm text-muted-foreground">
            <Link to="/about" className="hover:text-primary transition-colors">About Us</Link>
            <Link to="/contact" className="hover:text-primary transition-colors">Contact</Link>
          </div>
        </div>
        <div>
          <h4 className="font-display font-semibold mb-3">Contact</h4>
          <div className="flex flex-col gap-2 text-sm text-muted-foreground">
            <span>shashankh056@gmail.com</span>
            <span>+91 8310392745</span>
            <span>New Delhi, India</span>
          </div>
        </div>
      </div>
      <div className="border-t border-border mt-8 pt-6 text-center text-sm text-muted-foreground">
        © 2026 Delhi EV Charge. All rights reserved.
      </div>
    </div>
  </footer>
);

export default Footer;
