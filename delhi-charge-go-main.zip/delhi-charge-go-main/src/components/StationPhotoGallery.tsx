import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Camera, X } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";

interface Props {
  stationId: string;
}

const StationPhotoGallery = ({ stationId }: Props) => {
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);

  const { data: photos = [] } = useQuery({
    queryKey: ["station-photos", stationId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("station_photos" as any)
        .select("*")
        .eq("station_id", stationId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as any[];
    },
  });

  if (photos.length === 0) return null;

  return (
    <div className="bg-card border border-border rounded-2xl p-6 mb-6">
      <h2 className="font-display font-semibold mb-3 flex items-center gap-2">
        <Camera className="w-5 h-5 text-primary" /> Photos ({photos.length})
      </h2>
      <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
        {photos.map((p: any) => (
          <button
            key={p.id}
            onClick={() => setSelectedPhoto(p.photo_url)}
            className="aspect-square rounded-lg overflow-hidden border border-border hover:border-primary transition-colors"
          >
            <img
              src={p.photo_url}
              alt={p.caption || "Station photo"}
              className="w-full h-full object-cover"
              loading="lazy"
            />
          </button>
        ))}
      </div>

      <Dialog open={!!selectedPhoto} onOpenChange={() => setSelectedPhoto(null)}>
        <DialogContent className="max-w-2xl p-1">
          {selectedPhoto && (
            <img
              src={selectedPhoto}
              alt="Station photo"
              className="w-full rounded-lg"
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default StationPhotoGallery;
