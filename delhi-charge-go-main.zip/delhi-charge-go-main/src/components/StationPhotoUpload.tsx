import { useState, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ImagePlus, Loader2 } from "lucide-react";
import { toast } from "sonner";

interface Props {
  stationId: string;
  isAdmin?: boolean;
}

const StationPhotoUpload = ({ stationId, isAdmin = false }: Props) => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [caption, setCaption] = useState("");

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    if (!file.type.startsWith("image/")) {
      toast.error("Please select an image file");
      return;
    }

    setUploading(true);
    try {
      const ext = file.name.split(".").pop();
      const path = `${stationId}/${Date.now()}.${ext}`;

      const { error: uploadError } = await supabase.storage
        .from("station-photos")
        .upload(path, file);
      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage
        .from("station-photos")
        .getPublicUrl(path);

      const { error: dbError } = await supabase
        .from("station_photos" as any)
        .insert({
          station_id: stationId,
          user_id: user.id,
          photo_url: urlData.publicUrl,
          caption: caption.trim() || null,
          is_admin_upload: isAdmin,
        } as any);
      if (dbError) throw dbError;

      queryClient.invalidateQueries({ queryKey: ["station-photos", stationId] });
      setCaption("");
      toast.success("Photo uploaded!");
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  if (!user) return null;

  return (
    <div className="flex items-center gap-2">
      <Input
        placeholder="Caption (optional)"
        value={caption}
        onChange={(e) => setCaption(e.target.value)}
        className="flex-1 h-9 text-sm"
      />
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleUpload}
      />
      <Button
        variant="outline"
        size="sm"
        disabled={uploading}
        onClick={() => fileRef.current?.click()}
      >
        {uploading ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : (
          <ImagePlus className="w-4 h-4 mr-1" />
        )}
        {uploading ? "Uploading..." : "Add Photo"}
      </Button>
    </div>
  );
};

export default StationPhotoUpload;
