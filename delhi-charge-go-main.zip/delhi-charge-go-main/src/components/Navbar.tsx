import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Zap, Menu, X, Sun, Moon, LogIn, LogOut, CalendarCheck, Shield, UserCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/contexts/AuthContext";

interface NavbarProps {
  darkMode: boolean;
  toggleDarkMode: () => void;
}

const navItems = [
  { path: "/", label: "Home" },
  { path: "/map", label: "Map" },
  { path: "/stations", label: "Stations" },
  { path: "/booking", label: "Book" },
  { path: "/about", label: "About" },
  { path: "/contact", label: "Contact" },
];

const Navbar = ({ darkMode, toggleDarkMode }: NavbarProps) => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const { user, signOut } = useAuth();
  const isOwner = user?.email === "shashankh056@gmail.com";

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 ev-glass">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="w-9 h-9 rounded-lg ev-gradient-bg flex items-center justify-center">
            <Zap className="w-5 h-5 text-primary-foreground" />
          </div>
          <span className="font-display font-bold text-lg ev-gradient-text">
            Delhi EV Charge
          </span>
        </Link>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-1">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                location.pathname === item.path
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              }`}
            >
              {item.label}
            </Link>
          ))}
          <Button variant="ghost" size="icon" onClick={toggleDarkMode} className="ml-2">
            {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </Button>
          {user ? (
            <>
              <Link to="/my-bookings">
                <Button variant="ghost" size="sm" className="ml-1 text-muted-foreground">
                  <CalendarCheck className="w-4 h-4 mr-1" /> My Bookings
                </Button>
              </Link>
              <Link to="/profile">
                <Button variant="ghost" size="sm" className="ml-1 text-muted-foreground">
                  <UserCircle className="w-4 h-4 mr-1" /> Profile
                </Button>
              </Link>
              {isOwner && (
                <Link to="/admin">
                  <Button variant="ghost" size="sm" className="ml-1 text-muted-foreground">
                    <Shield className="w-4 h-4 mr-1" /> Admin
                  </Button>
                </Link>
              )}
              <Button variant="ghost" size="sm" onClick={signOut} className="ml-1 text-muted-foreground">
                <LogOut className="w-4 h-4 mr-1" /> Logout
              </Button>
            </>
          ) : (
            <Link to="/auth">
              <Button variant="ghost" size="sm" className="ml-1 text-primary">
                <LogIn className="w-4 h-4 mr-1" /> Login
              </Button>
            </Link>
          )}
        </div>

        {/* Mobile toggle */}
        <div className="flex md:hidden items-center gap-2">
          <Button variant="ghost" size="icon" onClick={toggleDarkMode}>
            {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>
      </div>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden ev-glass border-t border-border overflow-hidden"
          >
            <div className="px-4 py-3 flex flex-col gap-1">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setMobileOpen(false)}
                  className={`px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    location.pathname === item.path
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {item.label}
                </Link>
              ))}
              {user ? (
                <>
                  <Link to="/my-bookings" onClick={() => setMobileOpen(false)} className="px-3 py-2.5 rounded-lg text-sm font-medium text-muted-foreground">
                    My Bookings
                  </Link>
                  <Link to="/profile" onClick={() => setMobileOpen(false)} className="px-3 py-2.5 rounded-lg text-sm font-medium text-muted-foreground">
                    Profile
                  </Link>
                  {isOwner && (
                    <Link to="/admin" onClick={() => setMobileOpen(false)} className="px-3 py-2.5 rounded-lg text-sm font-medium text-muted-foreground">
                      Admin Dashboard
                    </Link>
                  )}
                  <button onClick={() => { signOut(); setMobileOpen(false); }} className="px-3 py-2.5 rounded-lg text-sm font-medium text-muted-foreground text-left">
                    Logout
                  </button>
                </>
              ) : (
                <Link to="/auth" onClick={() => setMobileOpen(false)} className="px-3 py-2.5 rounded-lg text-sm font-medium text-primary">
                  Login / Sign Up
                </Link>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
