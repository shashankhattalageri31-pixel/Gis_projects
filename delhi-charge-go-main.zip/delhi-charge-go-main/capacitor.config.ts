import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.b73dece0da2549b29975768557f66d30',
  appName: 'delhi-charge-go',
  webDir: 'dist',
  server: {
    url: 'https://b73dece0-da25-49b2-9975-768557f66d30.lovableproject.com?forceHideBadge=true',
    cleartext: true
  }
};

export default config;
