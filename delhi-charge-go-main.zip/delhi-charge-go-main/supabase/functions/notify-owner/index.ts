import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const OWNER_EMAIL = "shashankh056@gmail.com";

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
  if (!RESEND_API_KEY) {
    return new Response(JSON.stringify({ error: "RESEND_API_KEY not set" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  try {
    const body = await req.json();
    const { type, record } = body;

    let subject = "";
    let html = "";

    switch (type) {
      case "new_signup": {
        const email = record?.email || "unknown";
        const name = record?.display_name || email;
        subject = `🆕 New User Signup: ${name}`;
        html = `
          <div style="font-family:Arial,sans-serif;max-width:500px;margin:0 auto;padding:20px;">
            <h2 style="color:#22c55e;">New User Registration</h2>
            <p>A new user has signed up on Delhi ChargeGo:</p>
            <table style="width:100%;border-collapse:collapse;margin:16px 0;">
              <tr><td style="padding:8px;border-bottom:1px solid #eee;font-weight:600;">Name</td><td style="padding:8px;border-bottom:1px solid #eee;">${name}</td></tr>
              <tr><td style="padding:8px;border-bottom:1px solid #eee;font-weight:600;">Email</td><td style="padding:8px;border-bottom:1px solid #eee;">${email}</td></tr>
              <tr><td style="padding:8px;font-weight:600;">Signed Up</td><td style="padding:8px;">${new Date().toLocaleString()}</td></tr>
            </table>
          </div>`;
        break;
      }
      case "new_booking": {
        subject = `📅 New Booking: ${record?.vehicle_type || "Vehicle"}`;
        html = `
          <div style="font-family:Arial,sans-serif;max-width:500px;margin:0 auto;padding:20px;">
            <h2 style="color:#0ea5e9;">New Booking Created</h2>
            <p>A user has booked a charging slot:</p>
            <table style="width:100%;border-collapse:collapse;margin:16px 0;">
              <tr><td style="padding:8px;border-bottom:1px solid #eee;font-weight:600;">Vehicle</td><td style="padding:8px;border-bottom:1px solid #eee;">${record?.vehicle_type}</td></tr>
              <tr><td style="padding:8px;border-bottom:1px solid #eee;font-weight:600;">Date</td><td style="padding:8px;border-bottom:1px solid #eee;">${record?.booking_date}</td></tr>
              <tr><td style="padding:8px;border-bottom:1px solid #eee;font-weight:600;">Time</td><td style="padding:8px;border-bottom:1px solid #eee;">${record?.booking_time}</td></tr>
              <tr><td style="padding:8px;font-weight:600;">Status</td><td style="padding:8px;">${record?.status}</td></tr>
            </table>
          </div>`;
        break;
      }
      case "new_contact": {
        subject = `💬 New Contact Message from ${record?.name || "Unknown"}`;
        html = `
          <div style="font-family:Arial,sans-serif;max-width:500px;margin:0 auto;padding:20px;">
            <h2 style="color:#f59e0b;">New Contact Message</h2>
            <table style="width:100%;border-collapse:collapse;margin:16px 0;">
              <tr><td style="padding:8px;border-bottom:1px solid #eee;font-weight:600;">Name</td><td style="padding:8px;border-bottom:1px solid #eee;">${record?.name}</td></tr>
              <tr><td style="padding:8px;border-bottom:1px solid #eee;font-weight:600;">Email</td><td style="padding:8px;border-bottom:1px solid #eee;">${record?.email}</td></tr>
              <tr><td style="padding:8px;font-weight:600;">Message</td><td style="padding:8px;">${record?.message}</td></tr>
            </table>
          </div>`;
        break;
      }
      default:
        return new Response(JSON.stringify({ error: "Unknown type" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
    }

    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "Delhi ChargeGo <onboarding@resend.dev>",
        to: [OWNER_EMAIL],
        subject,
        html,
      }),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(`Resend error: ${JSON.stringify(data)}`);
    }

    return new Response(JSON.stringify({ success: true, id: data.id }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : "Unknown error";
    console.error("Notify error:", msg);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
