-- Create storage bucket for station photos
INSERT INTO storage.buckets (id, name, public) VALUES ('station-photos', 'station-photos', true);

-- Create station_photos table
CREATE TABLE public.station_photos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  station_id uuid NOT NULL REFERENCES public.charging_stations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  photo_url text NOT NULL,
  caption text,
  is_admin_upload boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.station_photos ENABLE ROW LEVEL SECURITY;

-- Anyone can view photos
CREATE POLICY "Anyone can view station photos" ON public.station_photos
  FOR SELECT USING (true);

-- Authenticated users can upload photos  
CREATE POLICY "Users can upload photos" ON public.station_photos
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- Users can delete own photos
CREATE POLICY "Users can delete own photos" ON public.station_photos
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Admins can manage all photos
CREATE POLICY "Admins can manage all photos" ON public.station_photos
  FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- Storage RLS policies
CREATE POLICY "Anyone can view station photos" ON storage.objects
  FOR SELECT USING (bucket_id = 'station-photos');

CREATE POLICY "Authenticated users can upload station photos" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (bucket_id = 'station-photos');

CREATE POLICY "Users can delete own station photos" ON storage.objects
  FOR DELETE TO authenticated USING (bucket_id = 'station-photos');
