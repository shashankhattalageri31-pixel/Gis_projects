
-- Drop old functions with CASCADE to remove dependent triggers
DROP FUNCTION IF EXISTS public.notify_new_contact() CASCADE;
DROP FUNCTION IF EXISTS public.notify_new_booking() CASCADE;
DROP FUNCTION IF EXISTS public.notify_new_signup() CASCADE;

-- Recreate using net.http_post (pg_net extension)
CREATE OR REPLACE FUNCTION public.notify_new_contact()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  PERFORM net.http_post(
    url := 'https://tsjwckuoujfeifqjnpey.supabase.co/functions/v1/notify-owner',
    headers := jsonb_build_object('Content-Type', 'application/json'),
    body := jsonb_build_object(
      'type', 'new_contact',
      'record', jsonb_build_object(
        'name', NEW.name,
        'email', NEW.email,
        'message', NEW.message
      )
    )
  );
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.notify_new_booking()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  PERFORM net.http_post(
    url := 'https://tsjwckuoujfeifqjnpey.supabase.co/functions/v1/notify-owner',
    headers := jsonb_build_object('Content-Type', 'application/json'),
    body := jsonb_build_object(
      'type', 'new_booking',
      'record', jsonb_build_object(
        'vehicle_type', NEW.vehicle_type,
        'booking_date', NEW.booking_date::text,
        'booking_time', NEW.booking_time::text,
        'status', NEW.status,
        'station_id', NEW.station_id::text
      )
    )
  );
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.notify_new_signup()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  PERFORM net.http_post(
    url := 'https://tsjwckuoujfeifqjnpey.supabase.co/functions/v1/notify-owner',
    headers := jsonb_build_object('Content-Type', 'application/json'),
    body := jsonb_build_object(
      'type', 'new_signup',
      'record', jsonb_build_object(
        'display_name', NEW.display_name,
        'email', NEW.display_name
      )
    )
  );
  RETURN NEW;
END;
$$;

-- Recreate triggers
CREATE TRIGGER on_new_contact_notify
  AFTER INSERT ON public.contact_messages
  FOR EACH ROW EXECUTE FUNCTION public.notify_new_contact();

CREATE TRIGGER on_new_booking_notify
  AFTER INSERT ON public.bookings
  FOR EACH ROW EXECUTE FUNCTION public.notify_new_booking();

CREATE TRIGGER on_new_signup_notify
  AFTER INSERT ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.notify_new_signup();
