-- Enable pg_net for HTTP requests from triggers
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

-- Function to notify on new bookings
CREATE OR REPLACE FUNCTION public.notify_new_booking()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  edge_url text;
  service_key text;
BEGIN
  edge_url := 'https://tsjwckuoujfeifqjnpey.supabase.co/functions/v1/notify-owner';
  service_key := current_setting('app.settings.service_role_key', true);
  
  PERFORM extensions.http_post(
    edge_url,
    jsonb_build_object(
      'type', 'new_booking',
      'record', jsonb_build_object(
        'vehicle_type', NEW.vehicle_type,
        'booking_date', NEW.booking_date::text,
        'booking_time', NEW.booking_time::text,
        'status', NEW.status,
        'station_id', NEW.station_id::text
      )
    )::text,
    'application/json'
  );
  RETURN NEW;
END;
$$;

-- Function to notify on new contact messages
CREATE OR REPLACE FUNCTION public.notify_new_contact()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  edge_url text;
BEGIN
  edge_url := 'https://tsjwckuoujfeifqjnpey.supabase.co/functions/v1/notify-owner';
  
  PERFORM extensions.http_post(
    edge_url,
    jsonb_build_object(
      'type', 'new_contact',
      'record', jsonb_build_object(
        'name', NEW.name,
        'email', NEW.email,
        'message', NEW.message
      )
    )::text,
    'application/json'
  );
  RETURN NEW;
END;
$$;

-- Function to notify on new signups (profiles table)
CREATE OR REPLACE FUNCTION public.notify_new_signup()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  edge_url text;
BEGIN
  edge_url := 'https://tsjwckuoujfeifqjnpey.supabase.co/functions/v1/notify-owner';
  
  PERFORM extensions.http_post(
    edge_url,
    jsonb_build_object(
      'type', 'new_signup',
      'record', jsonb_build_object(
        'display_name', NEW.display_name,
        'email', NEW.display_name
      )
    )::text,
    'application/json'
  );
  RETURN NEW;
END;
$$;

-- Create triggers
CREATE TRIGGER on_new_booking
  AFTER INSERT ON public.bookings
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_new_booking();

CREATE TRIGGER on_new_contact
  AFTER INSERT ON public.contact_messages
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_new_contact();

CREATE TRIGGER on_new_signup
  AFTER INSERT ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_new_signup();
