
-- Allow users to delete (cancel) their own bookings
CREATE POLICY "Users can delete own bookings" ON public.bookings
FOR DELETE TO authenticated
USING (auth.uid() = user_id);
